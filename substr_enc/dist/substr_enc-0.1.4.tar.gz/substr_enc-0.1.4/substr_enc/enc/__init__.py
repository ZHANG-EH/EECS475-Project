"""
Enc function initializer.

Jiangchen Zhu  <zjcsjtu@umich.edu>
Enhao Zhang    <ehzhang@umich.edu>
"""
from substr_enc.enc.encrypt import encrypt, key_gen
from substr_enc.enc.query import query_client
