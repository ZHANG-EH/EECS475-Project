"""
(Deprecated and unused)
Connection functions initializer

Jiangchen Zhu  <zjcsjtu@umich.edu>
"""
from substr_enc.conn.connection import sock_init, send_data, recv_data
