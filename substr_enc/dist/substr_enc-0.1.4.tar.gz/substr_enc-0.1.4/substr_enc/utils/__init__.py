"""
Utility structures and functions.

Jiangchen Zhu  <zjcsjtu@umich.edu>
"""
from substr_enc.utils.suffix_tree import Node, SuffixTree
