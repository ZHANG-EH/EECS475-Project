import substr_enc


LAMBDA = 32
